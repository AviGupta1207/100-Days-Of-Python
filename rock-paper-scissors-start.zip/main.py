import random
rock = '''
    _______
---'   ____)
      (_____)
      (_____)
      (____)
---.__(___)
'''

paper = '''
    _______
---'   ____)____
          ______)
          _______)
         _______)
---.__________)
'''

scissors = '''
    _______
---'   ____)____
          ______)
       __________)
      (____)
---.__(___)
'''

print("Welcome to Rock Paper Scissors!!!")
user_choice = input("Please Enter Your Choice R,P,S : ")
print("\n")
if user_choice == "R":
  print("You choose:\nRock")
  print(rock)
if user_choice == "P":
  print("You choose:\nPaper")
  print(paper)
if user_choice == "S":
  print("You choose:\nScissors")
  print(scissors)


cpu = random.randint(1,3)
if cpu == 1:
  cpu_choice = "R"
  print("CPU choose:\nRock")
  print(rock)
if cpu == 2:
  cpu_choice = "P"
  print("CPU choose:\nPaper")
  print(paper)
if cpu == 3:
  cpu_choice = "S"
  print("CPU choose:\nScissors")
  print(scissors)

if user_choice == cpu_choice:
  print("Match Tie!!")
elif (user_choice == "R") and (cpu_choice == "P"):
  print("You lose Please Try Again!!")
elif (user_choice == "R") and (cpu_choice == "S"):
  print("You Won")
elif (user_choice == "P") and (cpu_choice == "S"):
  print("You lose Please Try Again!!")
elif (user_choice == "P") and (cpu_choice == "R"):
  print("You Won")
elif (user_choice == "S") and (cpu_choice == "R"):
  print("You lose Please Try Again!!")
elif (user_choice == "S") and (cpu_choice == "P"):
  print("You Won")


