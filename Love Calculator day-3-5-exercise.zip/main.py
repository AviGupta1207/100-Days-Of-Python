# 🚨 Don't change the code below 👇
print("Welcome to the Love Calculator!")
name1 = input("What is your name? \n")
name2 = input("What is their name? \n")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇
count1 = 0
count2 = 0
name1 = name1.lower()
name2 = name2.lower()

name = name1+name2
T = name.count("t")
R = name.count("r")
U = name.count("u")
E = name.count("e")
score1 = str(T+R+U+E)
L = name.count("l")
O = name.count("o")
V = name.count("v")
E = name.count("e")
score2 = str(L+O+V+E)

# print(score1)
# print(score2)
Love_Scores = score1+score2
print(Love_Scores)
# if Love_Scores<10 and Love_Scores>90:
#   print(f"Your Score is {Love_Scores}, you go togethr like coke and mentos.")
# elif 50>Love_Scores>40:
#   print(f"Your score is {Love_Scores},you are alright together.")
# else:
#   print(f"Your Score is {Love_Scores}")

